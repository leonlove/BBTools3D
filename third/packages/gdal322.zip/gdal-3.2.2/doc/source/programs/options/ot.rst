.. option:: -ot <type>

    Force the output image bands to have a specific data type supported by the
    driver, which may be one of the following: ``Byte``, ``UInt16``,
    ``Int16``, ``UInt32``, ``Int32``, ``Float32``, ``Float64``, ``CInt16``,
    ``CInt32``, ``CFloat32`` or ``CFloat64``.
