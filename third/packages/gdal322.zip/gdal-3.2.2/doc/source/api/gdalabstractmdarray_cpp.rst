.. _gdalabstractmdarray_cpp:

================================================================================
GDALAbstractMDArray C++ API
================================================================================

.. doxygenclass:: GDALAbstractMDArray
   :project: api
   :members:
