.. _gdalattribute_cpp:

================================================================================
GDALAttribute C++ API
================================================================================

GDALAttribute class
-------------------

.. doxygenclass:: GDALAttribute
   :project: api
   :members:

GDALIHasAttribute interface
---------------------------

.. doxygenclass:: GDALIHasAttribute
   :project: api
   :members:
