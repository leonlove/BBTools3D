.. _cpl_api:

================================================================================
Common Portability Library C API
================================================================================

cpl_conv.h
----------

.. doxygenfile:: cpl_conv.h
   :project: api

cpl_csv.h
---------

.. doxygenfile:: cpl_csv.h
   :project: api

cpl_error.h
-----------

.. doxygenfile:: cpl_error.h
   :project: api

cpl_http.h
----------

.. doxygenfile:: cpl_http.h
   :project: api

cpl_minixml.h
-------------

.. doxygenfile:: cpl_minixml.h
   :project: api

cpl_multiproc.h
---------------

.. doxygenfile:: cpl_multiproc.h
   :project: api

cpl_port.h
----------

.. doxygenfile:: cpl_port.h
   :project: api

cpl_progress.h
--------------

.. doxygenfile:: cpl_progress.h
   :project: api

cpl_string.h
------------

.. doxygenfile:: cpl_string.h
   :project: api

cpl_time.h
----------

.. doxygenfile:: cpl_time.h
   :project: api

cpl_virtualmem.h
----------------

.. doxygenfile:: cpl_virtualmem.h
   :project: api

cpl_vsi_error.h
---------------

.. doxygenfile:: cpl_vsi_error.h
   :project: api

cpl_vsi.h
---------

.. doxygenfile:: cpl_vsi.h
   :project: api

.. seealso::

   :ref:`cpl_cpp_api`.
