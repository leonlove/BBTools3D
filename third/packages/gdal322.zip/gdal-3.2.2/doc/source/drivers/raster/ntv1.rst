.. _raster.ntv1:

================================================================================
NTv1 -- NTv1 Datum Grid Shift
================================================================================

.. shortname:: NTv1

.. built_in_by_default:: 

NOTE: Implemented as ``gdal/frmts/raw/ntv1dataset.cpp``.

Driver capabilities
-------------------

.. supports_georeferencing::

.. supports_virtualio::
