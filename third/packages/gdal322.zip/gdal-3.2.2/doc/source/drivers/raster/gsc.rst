.. _raster.gsc:

================================================================================
GSC -- GSC Geogrid
================================================================================

.. shortname:: GSC

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/raw/gscdataset.cpp``.

Driver capabilities
-------------------

.. supports_virtualio::

