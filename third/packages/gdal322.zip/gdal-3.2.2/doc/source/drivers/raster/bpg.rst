.. _raster.bpg:

================================================================================
BPG -- Better Portable Graphics
================================================================================

.. shortname:: BPG

.. build_dependencies:: libbpg (manual build required for now)

NOTE: Implemented as ``gdal/frmts/bpg/bpgdataset.cpp``.

