.. _raster.tsx:

================================================================================
TSX --  TerraSAR-X Product
================================================================================

.. shortname:: TSX

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/tsx/tsxdataset.cpp``.


Driver capabilities
-------------------

.. supports_georeferencing::

.. supports_virtualio::
