.. _raster.ctable2:

================================================================================
CTable2 -- CTable2 Datum Grid Shift
================================================================================

.. shortname:: CTable2

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/raw/ctable2dataset.cpp``.

Driver capabilities
-------------------

.. supports_createcopy::

.. supports_create::

.. supports_georeferencing::

.. supports_virtualio::

