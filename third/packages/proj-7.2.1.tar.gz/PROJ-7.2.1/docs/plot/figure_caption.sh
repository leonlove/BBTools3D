
python3 figure_captions.py plotdefs.json ../source/operations/projections/