
python3 plot.py plotdefs.json images/
