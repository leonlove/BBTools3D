.. _metadata:

metadata namespace
------------------

.. doxygennamespace:: osgeo::proj::metadata
   :project: doxygen_api
   :members:
