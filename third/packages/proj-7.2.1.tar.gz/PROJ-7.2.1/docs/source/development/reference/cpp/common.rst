.. _common:

common namespace
----------------

.. doxygennamespace:: osgeo::proj::common
   :project: doxygen_api
   :members:
