.. _util:

util namespace
--------------

.. doxygennamespace:: osgeo::proj::util
   :project: doxygen_api
   :members:
