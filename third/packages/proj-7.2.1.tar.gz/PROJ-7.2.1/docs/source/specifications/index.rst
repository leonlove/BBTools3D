.. _specifications:

================================================================================
Specifications
================================================================================

PROJ implements a number of extensions to standards, that are described below
for the sake of broader interoperability.

.. toctree::
   :maxdepth: 1

   projjson
   geodetictiffgrids
