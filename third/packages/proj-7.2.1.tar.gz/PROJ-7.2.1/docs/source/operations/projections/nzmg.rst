.. _nzmg:

********************************************************************************
New Zealand Map Grid
********************************************************************************

.. figure:: ./images/nzmg.png
   :width: 500 px
   :align: center
   :alt:   New Zealand Map Grid

   proj-string: ``+proj=nzmg``

Parameters
################################################################################

.. note:: All standard projection parameters are hard-coded for this projection
