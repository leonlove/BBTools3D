.. option:: +lat_2=<value>

    Second standard parallel.

    *Defaults to 0.0.*
