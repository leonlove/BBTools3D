.. option:: +h=<value>

    Height of the view point above the Earth and must be in the same units as
    the radius of the sphere or semimajor axis of the ellipsoid.

