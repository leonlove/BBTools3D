
============== r1 ============== (dead links)

* http://dl.google.com/android/ndk/android-ndk-1.5_r1-windows.zip
* http://dl.google.com/android/ndk/android-ndk-1.5_r1-darwin-x86.zip
* http://dl.google.com/android/ndk/android-ndk-1.5_r1-linux-x86.zip

============== r2 ==============

* http://dl.google.com/android/ndk/android-ndk-1.6_r1-windows.zip
* http://dl.google.com/android/ndk/android-ndk-1.6_r1-darwin-x86.zip
* http://dl.google.com/android/ndk/android-ndk-1.6_r1-linux-x86.zip

============== r3 ==============

* http://dl.google.com/android/ndk/android-ndk-r3-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r3-darwin-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r3-linux-x86.zip

============== r4 ==============

* http://dl.google.com/android/ndk/android-ndk-r4-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r4-darwin-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r4-linux-x86.zip

============== r4b ==============

* http://dl.google.com/android/ndk/android-ndk-r4b-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r4b-darwin-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r4b-linux-x86.zip

============== r5 ==============

* http://dl.google.com/android/ndk/android-ndk-r5-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r5-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r5-linux-x86.tar.bz2

============== r5b ==============

* http://dl.google.com/android/ndk/android-ndk-r5b-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r5b-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r5b-linux-x86.tar.bz2

============== r5c ==============

* http://dl.google.com/android/ndk/android-ndk-r5c-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r5c-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r5c-linux-x86.tar.bz2

============== r6 ==============

* http://dl.google.com/android/ndk/android-ndk-r6-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r6-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r6-linux-x86.tar.bz2

============== r6b ==============

* http://dl.google.com/android/ndk/android-ndk-r6b-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r6b-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r6b-linux-x86.tar.bz2

============== r7 ==============

* http://dl.google.com/android/ndk/android-ndk-r7-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r7-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r7-linux-x86.tar.bz2

============== r7b ==============

* http://dl.google.com/android/ndk/android-ndk-r7b-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r7b-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r7b-linux-x86.tar.bz2

============== r7c ==============

* http://dl.google.com/android/ndk/android-ndk-r7c-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r7c-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r7c-linux-x86.tar.bz2

============== r8 ==============

* http://dl.google.com/android/ndk/android-ndk-r8-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r8-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r8-linux-x86.tar.bz2

============== r8b ==============

* http://dl.google.com/android/ndk/android-ndk-r8b-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r8b-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r8b-linux-x86.tar.bz2

============== r8c ==============

* http://dl.google.com/android/ndk/android-ndk-r8c-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r8c-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r8c-linux-x86.tar.bz2

============== r8d ==============

* http://dl.google.com/android/ndk/android-ndk-r8d-windows.zip
* http://dl.google.com/android/ndk/android-ndk-r8d-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r8d-linux-x86.tar.bz2

============== r8e ==============

* http://dl.google.com/android/ndk/android-ndk-r8e-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r8e-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk-r8e-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r8e-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r8e-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r8e-linux-x86_64.tar.bz2

============== r9 ==============

* http://dl.google.com/android/ndk/android-ndk-r9-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r9-windows-x86-legacy-toolchains.zip
* http://dl.google.com/android/ndk/android-ndk-r9-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk-r9-windows-x86_64-legacy-toolchains.zip
* http://dl.google.com/android/ndk/android-ndk-r9-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9-darwin-x86-legacy-toolchains.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9-darwin-x86_64-legacy-toolchains.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9-linux-x86-legacy-toolchains.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9-linux-x86_64-legacy-toolchains.tar.bz2

============== r9b ==============

* http://dl.google.com/android/ndk/android-ndk-r9b-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r9b-windows-x86-legacy-toolchains.zip
* http://dl.google.com/android/ndk/android-ndk-r9b-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk-r9b-windows-x86_64-legacy-toolchains.zip
* http://dl.google.com/android/ndk/android-ndk-r9b-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9b-darwin-x86-legacy-toolchains.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9b-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9b-darwin-x86_64-legacy-toolchains.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9b-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9b-linux-x86-legacy-toolchains.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9b-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9b-linux-x86_64-legacy-toolchains.tar.bz2

============== r9c ==============

* http://dl.google.com/android/ndk/android-ndk-r9c-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r9c-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk-r9c-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9c-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9c-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9c-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9c-cxx-stl-libs-with-debugging-info.zip

============== r9d ==============

* http://dl.google.com/android/ndk/android-ndk-r9d-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk-r9d-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk-r9d-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9d-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9d-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9d-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r9d-cxx-stl-libs-with-debug-info.zip

============== r10 ==============

* http://dl.google.com/android/ndk/android-ndk32-r10-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk32-r10-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk32-r10-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk32-r10-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk32-r10-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk32-r10-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk64-r10-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk64-r10-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r10-cxx-stl-libs-with-debug-info.zip

============== r10b ==============

* http://dl.google.com/android/ndk/android-ndk32-r10b-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk32-r10b-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk32-r10b-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk32-r10b-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk32-r10b-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk32-r10b-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10b-windows-x86.zip
* http://dl.google.com/android/ndk/android-ndk64-r10b-windows-x86_64.zip
* http://dl.google.com/android/ndk/android-ndk64-r10b-darwin-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10b-darwin-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10b-linux-x86.tar.bz2
* http://dl.google.com/android/ndk/android-ndk64-r10b-linux-x86_64.tar.bz2
* http://dl.google.com/android/ndk/android-ndk-r10b-cxx-stl-libs-with-debug-info.zip

============== r10c ==============

* http://dl.google.com/android/ndk/android-ndk-r10c-windows-x86.exe
* http://dl.google.com/android/ndk/android-ndk-r10c-windows-x86_64.exe
* http://dl.google.com/android/ndk/android-ndk-r10c-darwin-x86.bin
* http://dl.google.com/android/ndk/android-ndk-r10c-darwin-x86_64.bin
* http://dl.google.com/android/ndk/android-ndk-r10c-linux-x86.bin
* http://dl.google.com/android/ndk/android-ndk-r10c-linux-x86_64.bin

============== r10d ==============

* http://dl.google.com/android/ndk/android-ndk-r10d-windows-x86.exe
* http://dl.google.com/android/ndk/android-ndk-r10d-windows-x86_64.exe
* http://dl.google.com/android/ndk/android-ndk-r10d-darwin-x86.bin
* http://dl.google.com/android/ndk/android-ndk-r10d-darwin-x86_64.bin
* http://dl.google.com/android/ndk/android-ndk-r10d-linux-x86.bin
* http://dl.google.com/android/ndk/android-ndk-r10d-linux-x86_64.bin
